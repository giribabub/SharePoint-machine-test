const radios = document.querySelectorAll('input[name="answer"]');
const submitBtn = document.getElementById('submitBtn');

radios.forEach((radio) => {
    radio.addEventListener('change', () => {
        submitBtn.disabled = false;
    });
});

submitBtn.addEventListener('click', () => {
    const selected = document.querySelector('input[name="answer"]:checked');

    if (!selected) {
        alert("Please select an option.");
        return;
    }

    alert(`Option ${selected.value} selected.`);
});
