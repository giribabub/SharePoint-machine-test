function checkPhoto(L, W, H) {
    if (W < L || H < L) {
        return "UPLOAD ANOTHER";
    }

    if (W === H) {
        return "ACCEPTED";
    }

    return "CROP IT";
}

document.getElementById("checkBtn").addEventListener("click", function () {
    const L = Number(document.getElementById("limit").value);
    const W = Number(document.getElementById("width").value);
    const H = Number(document.getElementById("height").value);

    const result = checkPhoto(L, W, H);

    document.getElementById("result").textContent = result;
});

/*
Sample:
L = 180
(640, 480) -> CROP IT
(120, 300) -> UPLOAD ANOTHER
(180, 180) -> ACCEPTED
*/
