WEB DEVELOPER MACHINE TEST - COMPLETE LOCAL PROJECT

This project is based on the supplied machine-test PPT.

PART 1:
HTML + CSS responsive layout.
The PPT specifies a 3-hour HTML/CSS test and asks for Flex, Grid,
Media Query and Bootstrap.

PART 2:
JavaScript problem solving.
The PPT specifies a 1-hour problem-solving test.

HOW TO RUN:
1. Extract this ZIP.
2. Open the folder in VS Code.
3. Open index.html with Live Server.
4. Test desktop, tablet and mobile using Chrome DevTools:
   Ctrl + Shift + M
5. Open problem.html for the JavaScript test.

FILES:
index.html   -> Responsive layout
style.css    -> Grid, Flexbox, Media Queries
script.js    -> Selection/Submit interaction
problem.html -> JavaScript problem UI
problem.js   -> Photo-dimension logic
images/      -> Reference option images extracted from the supplied PPT

IMPORTANT:
The original PPT says the actual images are provided in a ZIP package.
If the company provided a separate ZIP, replace the images in this
project with the official images from that package.
